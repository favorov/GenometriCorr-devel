### R code from vignette source 'GenometriCorr.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: set_options
###################################################
options(width=50)


###################################################
### code chunk number 2: load_genometricorr
###################################################
library('GenometriCorr')


###################################################
### code chunk number 3: read_files
###################################################
library('rtracklayer')
library('TxDb.Hsapiens.UCSC.hg19.knownGene')
refseq<-transcripts(TxDb.Hsapiens.UCSC.hg19.knownGene)
cpgis<-import(system.file("extdata", "UCSCcpgis_hg19.bed", package = "GenometriCorr"))
seqinfo(cpgis)<-seqinfo(TxDb.Hsapiens.UCSC.hg19.knownGene)[seqnames(seqinfo(cpgis))]
#refseq <- import("../extdata/UCSCrefseqgenes_hg19.bed")


###################################################
### code chunk number 4: dev_off_init
###################################################
(if (length(dev.list())) dev.off())


###################################################
### code chunk number 5: chr1_picture
###################################################
VisualiseTwoIRanges(ranges(cpgis[seqnames(cpgis)=='chr1']),ranges(refseq[seqnames(refseq)=='chr1']),nameA='CpG Islands',nameB='RefSeq Genes',chrom_length=seqlengths(TxDb.Hsapiens.UCSC.hg19.knownGene)['chr1'],title="CpGIslands and RefGenes on chr1 of Hg19")


###################################################
### code chunk number 6: test_chromosome_123
###################################################

permut.number<-100

cpgi_to_genes<-GenometriCorrelation(cpgis,refseq,chromosomes.to.proceed=c('chr1','chr2','chr3'),permut.number=permut.number,keep.distributions=TRUE,showProgressBar=FALSE)


###################################################
### code chunk number 7: report_chromosome_123
###################################################
print(cpgi_to_genes)


###################################################
### code chunk number 8: chromosome_1_graphical_report
###################################################
graphical.report(cpgi_to_genes,pdffile="CpGi_to_RefSeq_chr1_picture.pdf",show.chromosomes=c('chr1'),show.all=FALSE)


###################################################
### code chunk number 9: chromosome_1_visualize
###################################################
visualize(cpgi_to_genes,pdffile="CpGi_to_RefSeq_chr1_picture_vis.pdf",show.chromosomes=c('chr1'),show.all=FALSE)


###################################################
### code chunk number 10: read_config_file
###################################################
config<-new("GenometriCorrConfig",system.file("extdata", "template-config.ini", package = "GenometriCorr"))


###################################################
### code chunk number 11: print_config_file
###################################################
print(config)


###################################################
### code chunk number 12: change_config_file
###################################################
config$tests$ecdf.area.permut.number<-10
config$tests$mean.distance.permut.number<-10
config$tests$jaccard.measure.permut.number<-10
config$chromosomes <- "chr18"
config$showTkProgressBar=FALSE


###################################################
### code chunk number 13: read_more_files
###################################################
library('rtracklayer')
histones<-import(system.file("extdata", "chr18.H3K4me3.bed", package = "GenometriCorr"));
expr_genes<-import(system.file("extdata", "chr18.mRNAseq.bed", package = "GenometriCorr"));


###################################################
### code chunk number 14: run_config_file
###################################################
conf_res<-run.config(config,query=histones,reference=expr_genes)


###################################################
### code chunk number 15: simple_config_file
###################################################
quickconfig<-new("GenometriCorrConfig",system.file("extdata", "quick-config.ini", package = "GenometriCorr"))
print(quickconfig)


###################################################
### code chunk number 16: mapping_example_random
###################################################
population<-1000

chromo.length<-c('the_chromosome'=3000000)

names(chromo.length)<-c('the_chromosome')

rquery<-GRanges(ranges=IRanges(start=runif(population,1000000,2000000-10),width=c(10)),seqnames='the_chromosome',seqlengths=chromo.length)

rref<-GRanges(ranges=IRanges(start=runif(population,1000000,2000000-10),width=c(10)),seqnames='the_chromosome',seqlengths=chromo.length)

#create two features, they are randomly scattered in 1 000 000...2 000 000

unmapped_result<-GenometriCorrelation(rquery,rref,chromosomes.length=chromo.length,permut.number=permut.number,keep.distributions=FALSE,showProgressBar=FALSE)

#correlate them on the whole chromosome: 1...3 000 000

map_space<-GRanges(ranges=IRanges(start=c(1000000),end=c(2000000)),seqnames='the_chromosome',seqlengths=chromo.length)

mapped_rquery<-MapRangesToGenomicIntervals(what.to.map=rquery,where.to.map=map_space)

mapped_rref<-MapRangesToGenomicIntervals(what.to.map=rref,where.to.map=map_space)

#map them into 1 000 000...2 000 000

mapped_result<-GenometriCorrelation(mapped_rquery,mapped_rref,permut.number=permut.number,keep.distributions=FALSE,showProgressBar=FALSE)

#then, correlate again

cat('Unmapped result:\n')
print(unmapped_result)

cat('Mapped result:\n')
print(mapped_result)



###################################################
### code chunk number 17: simple_mapping_config_file
###################################################
mapconfig<-new("GenometriCorrConfig",system.file("extdata", "mapping-config.ini", package = "GenometriCorr"))
print(mapconfig)


###################################################
### code chunk number 18: H3K4ME3_example_random
###################################################
reads<-import(con=system.file("extdata", "GSM433170_BI.H1.H3K4me3.Solexa-8038_chr15.bed", package = "GenometriCorr"),format='bed')
interval<-GRanges(seqnames=c('chr15'),ranges=IRanges(start=c(73842345),width=c(10000000)))
reads.in.interval<-MapRangesToGenomicIntervals(interval,reads)
genes.in.interval<-MapRangesToGenomicIntervals(interval,refseq,unmapped.chromosome.warning = FALSE)
H3K4Me3.vs.genes<-GenometriCorrelation(reads.in.interval,genes.in.interval,showProgressBar = FALSE)

cat('H3K4Me3 vs genes in chr15:73842345-83842344:\n')
print(H3K4Me3.vs.genes)


###################################################
### code chunk number 19: chr15_picture
###################################################
VisualiseTwoIRanges(ranges(reads.in.interval),ranges(genes.in.interval),end=1000000,,nameA='H3K4ME3 reads',nameB='RefSeq Genes',title="H3K4Me3 vs RefGenes in chr15:73842345-83842344@Hg19")


